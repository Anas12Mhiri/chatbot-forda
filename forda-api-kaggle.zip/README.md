# Patient symptom care navigation API

This FastAPI starter supports symptom care navigation, not diagnosis. It does
not contain a medical rule set: the default policy conservatively returns
`medical_advice`. A clinician-reviewed policy can be injected with
`create_app(triage_policy=...)`. Policies may return an emergency level, a
focused follow-up question, or a care level. Emergency decisions are returned
immediately without a routine follow-up question.

Ollama classifies each message using a strict JSON schema and can answer general
informational, educational, or translation requests. It defaults to the local
`qwen3:4b` model at `http://localhost:11434`; pull it with
`ollama pull qwen3:4b`. Set `OLLAMA_MODEL` or `OLLAMA_BASE_URL` to change these.
Personalized diagnosis, treatment, or
medication requests are redirected to a healthcare professional. Emergency
rules take priority over routine classification. If model output is malformed
or Ollama is unavailable, the API conservatively returns `medical_advice`.
Ollama receives the user message to classify and answer general questions; the
API does not log raw symptom text. Do not include identifying information.

## Run

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
uvicorn app.main:app --reload
```

The browser chat is available at `http://127.0.0.1:8000/`, and interactive API
documentation is at `/docs`. The chat keeps up to eight recent turns in the
current browser tab only; reloading clears the conversation. `GET /health` is a
basic liveness check. `POST /chat` accepts a current message and optional
conversation history:

```json
{
  "message": "What does headache mean?",
  "conversation": [],
  "answers": []
}
```

The older `symptoms` request field remains supported for API clients.

Responses use one of `emergency`, `medical_advice`, or
`self_care_information`, `general_information`, `educational`, or
`translation` and include a professional-care disclaimer. Suspected emergencies
should be directed to local emergency services; no country or emergency number
is assumed. This starter does not provide medication doses or treatment
instructions.

## Run automated tests

```powershell
python -m unittest discover -s tests -v
```
