"""HTTP routes for chat and liveness checks."""

import logging
from pathlib import Path

from fastapi import APIRouter
from fastapi.responses import FileResponse

from app.intent import IntentClassificationError, IntentClassifier
from app.llm import QuestionRefiner
from app.schemas import ChatRequest, ChatResponse, FollowUpQuestion
from app.triage import TriagePolicy

logger = logging.getLogger(__name__)

DISCLAIMER = (
    "This service is not a substitute for professional medical care. "
    "If you suspect an emergency, contact your local emergency services now."
)


def build_router(
    policy: TriagePolicy,
    refiner: QuestionRefiner,
    classifier: IntentClassifier,
) -> APIRouter:
    """Create endpoints bound to the configured policy and question refiner."""
    router = APIRouter()

    @router.get("/", include_in_schema=False)
    async def chat_page() -> FileResponse:
        """Serve the browser-based chat client."""
        return FileResponse(Path(__file__).parent / "static" / "index.html")

    @router.get("/health", tags=["health"])
    async def health() -> dict[str, str]:
        """Basic liveness check."""
        return {"status": "ok"}

    @router.post("/chat", response_model=ChatResponse, tags=["chat"])
    async def chat(request: ChatRequest) -> ChatResponse:
        """Evaluate a symptom description under the configured rules policy."""
        try:
            # Clinician-reviewed emergency rules have priority over routine intent.
            result = policy.evaluate(request.current_message, request.answers)
        except Exception:
            # Do not include exception text or symptom content in application logs.
            logger.error("Triage policy failed")
            return ChatResponse(
                level="medical_advice",
                message="I cannot determine an appropriate care level right now. Please contact a healthcare professional for advice.",
                disclaimer=DISCLAIMER,
            )

        # Never let an emergency rule proceed into routine classification/questions.
        if result.level == "emergency":
            return ChatResponse(
                level="emergency",
                message="Your responses match an emergency rule. Contact your local emergency services now.",
                disclaimer=DISCLAIMER,
            )

        try:
            classification = await classifier.classify(
                request.current_message,
                request.conversation,
            )
        except IntentClassificationError:
            return ChatResponse(
                level="medical_advice",
                message="I cannot safely classify this request right now. Please contact a healthcare professional for personalized advice.",
                disclaimer=DISCLAIMER,
            )

        if classification.intent == "emergency":
            return ChatResponse(
                level="emergency",
                message="This may require urgent help. Contact your local emergency services now.",
                disclaimer=DISCLAIMER,
            )

        if classification.intent in {"general_information", "educational", "translation"}:
            return ChatResponse(
                level=classification.intent,
                message=classification.answer,
                disclaimer=DISCLAIMER,
            )

        if result.level is None and result.question_id and result.question_text:
            try:
                question_text = await refiner.refine(result.question_text)
            except Exception:
                logger.warning("Question wording provider failed; using policy text")
                question_text = result.question_text
            return ChatResponse(
                level="medical_advice",
                message="I need one more detail to guide the next step. If you remain unsure, contact a healthcare professional.",
                follow_up_question=FollowUpQuestion(
                    question_id=result.question_id,
                    text=question_text,
                ),
                disclaimer=DISCLAIMER,
            )

        # Personalized requests always receive a professional-care redirect.
        # The model's answer is intentionally discarded for this intent.
        level = "medical_advice"
        messages = {
            "medical_advice": "I cannot provide a personalized diagnosis or treatment recommendation. Please contact a qualified healthcare professional for advice.",
            "self_care_information": "The configured rules indicate that general self-care information may be appropriate. Contact a healthcare professional if you are concerned or symptoms change.",
        }
        return ChatResponse(
            level=level,
            message=messages.get(level, messages["medical_advice"]),
            disclaimer=DISCLAIMER,
        )

    return router
