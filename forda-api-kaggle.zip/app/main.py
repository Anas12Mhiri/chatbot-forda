"""FastAPI application for patient symptom care navigation."""

from fastapi import FastAPI

from app.intent import IntentClassifier
from app.llm import QuestionRefiner
from app.routes import build_router
from app.triage import ConservativeDefaultPolicy, TriagePolicy


def create_app(
    triage_policy: TriagePolicy | None = None,
    question_refiner: QuestionRefiner | None = None,
    intent_classifier: IntentClassifier | None = None,
) -> FastAPI:
    """Build an app with injectable rules and Ollama intent classification."""
    policy = triage_policy or ConservativeDefaultPolicy()
    refiner = question_refiner or QuestionRefiner()
    classifier = intent_classifier or IntentClassifier()
    api = FastAPI(
        title="Patient Symptom Care Navigation API",
        version="0.1.0",
        description="Care navigation only; this service does not diagnose conditions.",
    )
    api.include_router(build_router(policy, refiner, classifier))
    return api


app = create_app()
