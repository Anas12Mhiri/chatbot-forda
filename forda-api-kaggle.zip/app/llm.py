"""Optional follow-up wording refinement; the LLM never makes triage decisions."""

import logging
import os

import httpx

logger = logging.getLogger(__name__)


class QuestionRefiner:
    """Optionally rephrase questions through Ollama's native chat API."""

    def __init__(self) -> None:
        self.model = os.getenv("OLLAMA_MODEL", "qwen3:4b")
        self.base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")

    async def refine(self, question: str) -> str:
        """Return a concise wording or the original question on any provider failure."""
        payload = {
            "model": self.model,
            "stream": False,
            "options": {"temperature": 0},
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "Rephrase the supplied clinician-authored follow-up question in "
                        "plain, neutral language. Return one question only. Do not add "
                        "questions, advice, diagnosis, urgency, or treatment instructions."
                    ),
                },
                {"role": "user", "content": question},
            ],
        }
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.post(
                    f"{self.base_url}/api/chat",
                    json=payload,
                )
                response.raise_for_status()
                text = response.json()["message"]["content"]
                if isinstance(text, str) and text.strip() and len(text) <= 500:
                    return text.strip()
        except (httpx.HTTPError, KeyError, IndexError, TypeError, ValueError):
            logger.warning("Question wording provider unavailable; using policy text")
        return question
