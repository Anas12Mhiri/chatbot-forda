"""Patient symptom triage API."""
